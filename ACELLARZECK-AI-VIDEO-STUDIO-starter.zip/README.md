# ACELLARZECK AI VIDEO STUDIO

Starter Android application using a dark interface and bilingual English/Indonesian labels.

## Build APK with GitHub Actions
1. Upload the contents of this project to the root of your GitHub repository.
2. Open the **Actions** tab.
3. Select **Build ACELLARZECK AI VIDEO STUDIO APK**.
4. Run the workflow with **Run workflow** (or push to `main`).
5. Download the `ACELLARZECK-AI-VIDEO-STUDIO-debug` artifact from the completed run.

This is the initial UI foundation. AI video generation is not connected yet; it requires selecting an AI video provider and securely configuring its API.
