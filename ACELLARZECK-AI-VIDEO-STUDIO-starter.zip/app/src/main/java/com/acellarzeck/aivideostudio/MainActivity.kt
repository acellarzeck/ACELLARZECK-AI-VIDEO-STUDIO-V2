package com.acellarzeck.aivideostudio

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 15, 24)
    private val panel = Color.rgb(25, 31, 46)
    private val accent = Color.rgb(83, 150, 255)
    private var language = "both"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 32)
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = text("ACELLARZECK", 14, accent, true)
        root.addView(brand)
        root.addView(text("AI VIDEO STUDIO", 28, Color.WHITE, true))
        root.addView(text("Create your next story with AI.\nBuat cerita berikutnya dengan AI.", 15, 0xFFB8C2D8.toInt(), false).padTop(8))
        root.addView(section("CREATE / BUAT"))
        root.addView(actionCard("Text to Video", "Teks menjadi video", "Coming soon / Segera hadir"))
        root.addView(actionCard("Image to Video", "Foto menjadi video", "Coming soon / Segera hadir"))
        root.addView(section("PROJECT SETTINGS / PENGATURAN"))
        root.addView(actionCard("Video format / Rasio video", "9:16  •  16:9  •  1:1", "Choose your format / Pilih rasio"))
        root.addView(actionCard("Video duration / Durasi video", "5s  •  10s  •  15s", "Choose duration / Pilih durasi"))
        root.addView(section("MY WORK / KARYA SAYA"))
        root.addView(text("Your generated videos will appear here.\nVideo yang kamu buat akan muncul di sini.", 14, 0xFFB8C2D8.toInt(), false).padTop(4))
        val footer = text("Version 1.0 • ACELLARZECK", 12, 0xFF77839B.toInt(), false)
        footer.gravity = Gravity.CENTER
        root.addView(footer.padTop(28))
    }

    private fun section(label: String): TextView =
        text(label, 13, accent, true).padTop(26)

    private fun actionCard(title: String, subtitle: String, message: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(panel)
        }
        card.addView(text(title, 18, Color.WHITE, true))
        card.addView(text(subtitle, 13, 0xFFB8C2D8.toInt(), false).padTop(5))
        val button = Button(this).apply {
            text = message
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "AI generation will be connected in the next development stage.", Toast.LENGTH_LONG).show()
            }
        }
        card.addView(button)
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.topMargin = 12
        card.layoutParams = params
        return card
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun TextView.padTop(dp: Int): TextView {
        setPadding(paddingLeft, dp, paddingRight, paddingBottom)
        return this
    }
}
